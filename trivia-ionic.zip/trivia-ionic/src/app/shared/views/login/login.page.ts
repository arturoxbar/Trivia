import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Capacitor } from '@capacitor/core';
import { LoadingService } from 'src/app/core/services/loading.service';
import { SessionService } from 'src/app/core/services/session.service';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  form: FormGroup = new FormGroup({
    password: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
  });

  constructor(
    private _sessionService: SessionService,
    private _router: Router, 
    private _toastService: ToastService,
    private _loadingService: LoadingService
  ) { }

  ngOnInit() {
  }

  async login(){

    let {email, password} = this.form.value;
    await this._loadingService.presentLoading();

    this._sessionService.login(email, password).subscribe(
      (res:any)=>{
        
        if(res.status == 200){
          this._router.navigate(['/dashboard']);
        }else{
          this._toastService.presentToast({
            message: res.message,
            color: 'danger',
            duration: 3000
          });
        }

        this._loadingService.dismissLoading();
      },
      (error)=>{
        this._toastService.presentToast({
          message: 'Error de conexion con el servidor',
          color: 'danger',
          duration: 3000
        });
        
        this._loadingService.dismissLoading();
      }
    );
  }

  ionViewDidLeave(){
    this.form.reset();
  }

}
