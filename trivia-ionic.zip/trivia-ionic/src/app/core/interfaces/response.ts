export interface Response {
    status: number;
    message: string;
    data: any;
}