import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from './services/toast.service';
import { GlobalService } from './services/global.service';
import { SessionService } from './services/session.service';
import { IonicStorageModule } from '@ionic/storage-angular';
import { StorageService } from './services/storage.service';
import { AlertService } from './services/alert.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    IonicStorageModule.forRoot(),
    HttpClientModule
  ],
  providers: [
    ToastService,
    GlobalService,
    SessionService,
    StorageService,
    AlertService
  ]
})
export class CoreModule { }
