import { Injectable } from '@angular/core';
import { LoadingController, LoadingOptions } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {

  private loading: HTMLIonLoadingElement;

  constructor(public loadingController: LoadingController) {
  }

  async presentLoading(options: LoadingOptions = {}) {

    if(!this.loading){
      this.loading = await this.loadingController.create({
        cssClass: options.cssClass,
        message: options.message || 'Cargando...',
        duration: options.duration || 0,
      });
      await this.loading.present();
    }
  }

  async dismissLoading() {
    if(this.loading){
      await this.loading.dismiss();
      this.loading = null;
    }
  }

}
