import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { environment } from 'src/environments/environment';
import { StorageService } from './storage.service';
import { Device } from '@capacitor/device';

//GlobalService se encargará de tener todas las variables globales que sean necesarias para el funcionamiento de la aplicación.
//Ademas de eso, las funciones que pueden ser utilizadas por toda la aplicación.
//Como son functiones de validaciones, o calculos de fechas, etc.
@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  apiUrl: string = environment.apiUrl;
  token: string;

  constructor(
    private _storeService: StorageService,
  ) {
  }

  /**
   * 
   * @param auth | Si se desea hacer la peticion usando el token de autenticacion
   * @param body | Si se desea enviar un body a la peticion
   * @returns | Retorna una promesa con el resultado de la peticion
   */
  headersBuilder(auth?: boolean, body?: string) {

    let headers: HttpHeaders;
    let requestOptions: any;

    if(body){
      headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      });
    }else{
      headers = new HttpHeaders()
    }

    if(auth){
      headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.token}`
      });
    }

    requestOptions = {
      headers,
    }

    if(body){
      requestOptions.body = body;
    }

    return requestOptions;

  }

  setToken(token: string){
    this.token = token;
    this._storeService.set('token', token);
  }

  getIsAuth(): boolean{
    return this.token ? true : false;
  }

}
