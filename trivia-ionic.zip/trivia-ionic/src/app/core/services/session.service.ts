import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { User } from '../interfaces/user.interface';
import { GlobalService } from './global.service';

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  private url = `${this._globalService.apiUrl}/user`;

  token: string;
  user: User = {
    id: 0,
    fullname: "",
    email: "",
  };

  constructor(
    private _globalService: GlobalService,
    private _http: HttpClient,
    private _router: Router
  ) { 
  }

  login(email: string, password: string){
    const form = JSON.stringify({email, password});
    const header = this._globalService.headersBuilder(false, form);
    return this._http.post<User>(`${this.url}/login`, form, header).pipe(
      map((res: any) => {
        if(res.status == 200){
          this.token = res.data.token;
          this._globalService.setToken(this.token);
          this.user = {
            id: res.data.profile.id,
            fullname: res.data.profile.name,
            email: res.data.profile.email
          }
        }
        return res;
      }
    ));
  }

  register(user: User){
    const form = JSON.stringify(user);
    const header = this._globalService.headersBuilder(false, form);
    return this._http.post<User>(`${this.url}/register`, form, header).pipe(
      map((res: any) => {
        if(res.status == 200){
   //       this.token = res.data.token;
     //     this._globalService.setToken(this.token);
        }
        return res;
      }
    ));
  }

  logout(){
    
    this.token = null;
    this.user = {
      id: 0,
      fullname: "",
      email: ""
    };

    this._globalService.setToken(null);
    this._router.navigate(['/login']);

  }


}
