import { Injectable } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class AlertService {

  constructor(
    private _alertController: AlertController
  ) { }
  
  async presentAlert(header: string, message: string) {
    const alert = await this._alertController.create({
      header,
      message,
      buttons: ['OK']
    });

    await alert.present();
  }

  async presentAlertConfirm(
    header: string, message: string,
    confirmText: string = 'Ok', cancelText: string = 'Cancelar',
  ) {

    const alert = await this._alertController.create({
      header,
      message,
      buttons: [
        {
          text: cancelText,
          role: 'cancel',
          cssClass: 'secondary',
          id: 'cancel-button',
        }, 
        {
          text: confirmText,
          role: 'ok',
          id: 'confirm-button',
        }
      ]
    });

    await alert.present();    
    let {role} = await alert.onDidDismiss();

    if(role == 'ok')
      return null;
    else
      throw null;

  }

}
