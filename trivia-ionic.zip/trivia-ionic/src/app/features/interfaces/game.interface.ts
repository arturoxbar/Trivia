export type difficulty = 'easy' | 'medium' | 'hard';

export type type = 'multiple' | 'boolean';

export interface Question {
    category: number;
    type: type;
    difficulty: difficulty;
    question: string;
    correct_answer: string;
    incorrect_answers: string[];
}

export interface Response {
    response_code: number;
    results: Question[];
}

export interface Answer { 
    text: string;
    correct: boolean;
}