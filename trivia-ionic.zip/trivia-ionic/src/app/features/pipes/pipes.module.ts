import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParseSymbolPipe } from './parse-symbol.pipe';



@NgModule({
  declarations: [
    ParseSymbolPipe
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ParseSymbolPipe
  ]
})
export class PipesModule { }
