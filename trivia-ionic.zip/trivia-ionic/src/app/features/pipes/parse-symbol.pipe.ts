import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'parseSymbol'
})
export class ParseSymbolPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): string {

    if(value){

      // Parse symbol ej &quot or &amp or &lt or &gt or &nbsp or others;
      let text = value.toString().replace(/&quot;/g, '"');
      text = text.replace(/&amp;/g, '&');
      text = text.replace(/&lt;/g, '<');
      text = text.replace(/&gt;/g, '>');
      text = text.replace(/&nbsp;/g, ' ');
      text = text.replace(/&#39;/g, '\'');
      text = text.replace(/&#34;/g, '"');
      text = text.replace(/&#x27;/g, '\'');
      text = text.replace(/&#x60;/g, '`');
      text = text.replace(/&#x2F;/g, '/');
      text = text.replace(/&#x3F;/g, '?');
      text = text.replace(/&#x3A;/g, ':');
      text = text.replace(/&#x3B;/g, ';');
      text = text.replace(/&#x3D;/g, '=');
      text = text.replace(/&#039;/g, '\'');      


      return text;

    }

    return "";

  }

}
