import { ParseSymbolPipe } from './parse-symbol.pipe';

describe('ParseSymbolPipe', () => {
  it('create an instance', () => {
    const pipe = new ParseSymbolPipe();
    expect(pipe).toBeTruthy();
  });
});
