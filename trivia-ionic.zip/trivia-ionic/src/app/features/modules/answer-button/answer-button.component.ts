import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-answer-button',
  templateUrl: './answer-button.component.html',
  styleUrls: ['./answer-button.component.css']
})
export class AnswerButtonComponent {

  @Input() text: string;
  @Input() correct: boolean;
  @Input() animatedAnswer: boolean;
  
  constructor() { }

}
