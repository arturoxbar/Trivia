import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnswerButtonComponent } from './answer-button.component';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from '../../pipes/pipes.module';



@NgModule({
  declarations: [
    AnswerButtonComponent
  ],
  imports: [
    CommonModule,
    IonicModule,
    PipesModule
  ],
  exports: [
    AnswerButtonComponent
  ]
})
export class AnswerButtonModule { }
