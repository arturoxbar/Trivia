import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuestionTextComponent } from './question-text.component';
import { PipesModule } from '../../pipes/pipes.module';



@NgModule({
  declarations: [
    QuestionTextComponent
  ],
  imports: [
    CommonModule,
    PipesModule
  ],
  exports: [
    QuestionTextComponent
  ]
})
export class QuestionTextModule { }
