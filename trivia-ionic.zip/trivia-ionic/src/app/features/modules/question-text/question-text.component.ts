import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-question-text',
  templateUrl: './question-text.component.html',
  styleUrls: ['./question-text.component.css']
})
export class QuestionTextComponent implements OnInit{

  @Input('text') text: string;

  constructor() { }

  ngOnInit(): void {
  }

}
