import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BaseComponent } from './views/base/base.component';
import { IonicModule } from '@ionic/angular';
import { AuthdGuard } from './guards/authd.guard';
import { ParseSymbolPipe } from './pipes/parse-symbol.pipe';

const routes: Routes = [
  {
    path: '',
    canActivate: [AuthdGuard],
    component: BaseComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./views/dashboard/dashboard.module').then( m => m.DashboardPageModule)
      },
      {
        path: 'play',
        loadChildren: () => import('./views/game/game.module').then( m => m.GamePageModule)
      },
      {
        path: 'play/rush',
        loadChildren: () => import('./views/game-rush/game-rush.module').then( m => m.GameRushPageModule)
      },
      {
        path: 'leaderboard',
        loadChildren: () => import('./views/leaderboard/leaderboard.module').then( m => m.LeaderboardPageModule)
      },
    ]
  },
]

@NgModule({
  declarations: [
    BaseComponent    
  ],
  imports: [
    CommonModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    AuthdGuard
  ],
  exports: [
  ]
})
export class FeaturesModule { }
