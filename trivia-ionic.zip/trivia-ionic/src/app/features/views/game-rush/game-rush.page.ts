import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Answer, Question } from '../../interfaces/game.interface';
import { GameService } from '../../services/game.service';

@Component({
  selector: 'app-game-rush',
  templateUrl: './game-rush.page.html',
  styleUrls: ['./game-rush.page.scss'],
})
export class GameRushPage implements OnDestroy {

  questions: Question[] = [];
  actualQuestion: Question;
  actualAnswerList: Answer[] = [];

  correctCounter: number = 0;
  incorrectCounter: number = 0;

  score: number = 0;
  isFinishGame: boolean = false;

  isShowAnimatedAnswer: boolean = false;

  timeBase: number = 20;
  time: number = this.timeBase;
  intervalTime: any;

  constructor(
    private _gameService: GameService,
    private _router: Router
  ) { }

  ionViewDidEnter() {
    this.getQuestions();
  }

  ngOnDestroy(){
    if(this.intervalTime){
      clearInterval(this.intervalTime);
      this.intervalTime = null;
    }
  }

  getQuestions() {
    this._gameService.getQuestions(20).subscribe((res: any)=>{
      this.questions = [...this.questions, ...res.results];

      if(!this.intervalTime){
        this.showNewQuestion();
        this.intervalTime = setInterval(()=>{
          if(!this.isShowAnimatedAnswer){
            this.time = +(this.time - 0.1).toFixed(2);
            if(this.time == 0){
              this.finishGame();
            }
          }
        }, 100);
      }
    });
  }

  assignAnswers() {
    this.actualAnswerList = this.shuffle([
      {text: this.actualQuestion.correct_answer, correct: true},
      ...this.actualQuestion.incorrect_answers.map(answer => {
        return {text: answer, correct: false};
      }),
    ]);
  }

  onAnswerClick(isCorrect: boolean){

    this.isShowAnimatedAnswer = true;

    if(isCorrect){
      
      this.correctCounter++;

      if(this.correctCounter % 5 == 0){
        this.time = this.time + 10;
      }

      if(this.questions.length < 10){
        this.getQuestions();
      }

    }

    setTimeout(()=>{

      this.isShowAnimatedAnswer = false;

      if(isCorrect){
        this.showNewQuestion();
      }else{
        this.finishGame();
      }

    }, 2000);

  }

  showNewQuestion(){
    this.actualQuestion = this.questions.shift();
    this.assignAnswers();    
  }

  finishGame(){

    this.isFinishGame = true;
    this.score = this.calculateScore(this.time, this.correctCounter, this.incorrectCounter);

    this._gameService.uploadScore(this.score, 2).subscribe((res: any)=>{
      console.log(res);
    });

    clearInterval(this.intervalTime);

    this.intervalTime = null;
    this.questions = [];
    this.actualQuestion = null;
    this.actualAnswerList = [];
    this.correctCounter = 0;
    this.incorrectCounter = 0;
    this.time = this.timeBase;

  }

  onRestartGame(){
    this.isFinishGame = false;
    this.getQuestions();
  }

  onBackToHome(){
    this._router.navigate(['/dashboard']);
    this.isFinishGame = false;
  }

  calculateScore(time, correct, incorrect){
    let score = correct * 10;
    return score < 0 ? 0 : score;
  }

  shuffle(array: any[] = []) {

    let currentIndex = array.length, temporaryValue, randomIndex;
    
    while (0 !== currentIndex) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }

    return array;
  }

}
