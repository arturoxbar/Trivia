import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GamePageRoutingModule } from './game-routing.module';

import { GamePage } from './game.page';
import { QuestionTextModule } from '../../modules/question-text/question-text.module';
import { AnswerButtonModule } from '../../modules/answer-button/answer-button.module';
import { LoadingModule } from '../../modules/loading/loading.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GamePageRoutingModule,

    QuestionTextModule,
    AnswerButtonModule,
    LoadingModule
  ],
  declarations: [GamePage]
})
export class GamePageModule {}
