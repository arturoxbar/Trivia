import { Component, OnInit } from '@angular/core';
import { GameService } from '../../services/game.service';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.page.html',
  styleUrls: ['./leaderboard.page.scss'],
})
export class LeaderboardPage implements OnInit {

  loadingRush: boolean = false;
  loadingNormal: boolean = false;

  scoresNormal: Score[] = [];
  scoresRush: Score[] = [];
  scoresHandle: Score[] = [];

  segment: string = "Normal";

  constructor(
    private _gameService: GameService
  ) { }

  ngOnInit() {
    this.getLeaderboardNormal();
    this.getLeaderboardRush();
  }

  getLeaderboardNormal() {
    this.loadingNormal = true;
    this._gameService.getScores(1).subscribe((res: any)=>{
      if(res.status === 200){
        this.loadingNormal = false;
        this.scoresNormal = [];
        for(let score of res.data.scores){
          this.scoresNormal.push(score);
        }
        if(this.segment === 'Normal'){
          this.scoresHandle = this.scoresNormal.splice(0, 10);
        }
      }
    })
  }

  getLeaderboardRush() {
    this.loadingRush = true;
    this._gameService.getScores(2).subscribe((res: any)=>{
      if(res.status === 200){
        this.loadingNormal = true;
        this.scoresRush = [];
        for(let score of res.data.scores){
          this.scoresRush.push(score);
        }
        if(this.segment === 'Rush'){
          this.scoresHandle = this.scoresRush.splice(0, 10);
        }
      }
    })
  }

  segmentChanged($event){
    
    this.segment = $event.detail.value;
    
    switch(this.segment){
      case 'Normal':
        this.scoresHandle = this.scoresNormal.splice(0, 10);
        this.getLeaderboardNormal();
        break;
      case 'Rush':
        this.scoresHandle = this.scoresRush.splice(0, 10);
        this.getLeaderboardRush();
        break;
    }

  }

}

interface Score {
  score: number;
  name: string;
  type_game_title: string;
}