import { Component, OnInit } from '@angular/core';
import { SessionService } from 'src/app/core/services/session.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {

  username: string;

  constructor(
    private _ss: SessionService,
  ) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.username = this._ss.user.fullname;
    console.log(this._ss.user)
  }

}
