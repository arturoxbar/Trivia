import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GlobalService } from 'src/app/core/services/global.service';
import { difficulty, Response } from '../interfaces/game.interface';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  urlExternalApi: string = "https://opentdb.com/api.php"
  urlInternalApi: string = `${this._glboalService.apiUrl}/game`;

  constructor(
    private http: HttpClient,
    private _glboalService: GlobalService
  ) { }

  getQuestions(amount: number = 10, difficulty?: difficulty, category?: number){
    let options = this._glboalService.headersBuilder();
    options.params = {};
    if(difficulty)
      options.params.difficulty = difficulty;
    if(category)
      options.params.category = category;
    options.params.amount = amount;
    return this.http.get(`${this.urlExternalApi}` , options);
  }

  uploadScore(score: number, type_game_id: number){
    let body = JSON.stringify({score, type_game_id});
    let options = this._glboalService.headersBuilder(true, body)
    return this.http.post(`${this.urlInternalApi}/score`, body, options);
  }

  getScores(type_game_id: number, show_id?: number){
    let options = this._glboalService.headersBuilder(true);
    if(type_game_id)
      options.params = {type_game_id};
    if(show_id)
      options.params.show_id = show_id;
    return this.http.get(`${this.urlInternalApi}/scores`, options);
  }

}
