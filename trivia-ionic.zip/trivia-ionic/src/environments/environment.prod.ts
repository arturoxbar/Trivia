export const environment = {
  production: true,
  hostname: 'trivia-ionic.herokuapp.com',
  apiUrl: 'https://trivia-ionic.herokuapp.com/api/v1',
};
