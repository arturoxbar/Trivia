import { Request, Response } from "express";
import { Controller } from "./controller";
import gameService from '../services/game';

class GameController extends Controller{

    constructor(){
        super('Game');
    }

    // CRUDS
    setScore = async (req: Request, res: Response) => {
        const response = this.getResponse();
        try{
            const { score, type_game_id } = req.body;
            const user_id = req.user.id;
            const scoreCreated = await gameService.setScore(score, type_game_id, user_id);
            response.data = scoreCreated;
        } catch(error){
            if(response.status === 200){
                response.status = 500;
                response.message = "SERVER_ERROR";
            }
        }finally{
            res.send(response);
        }
    }

    getScores = async (req: Request, res: Response) => {
        const response = this.getResponse();
        try{
            let scoresId;
            var { type_game_id = 1, show_id } = req.query;

            const scores = await gameService.getScores(+type_game_id);

            if(show_id)
                scoresId = await gameService.getScoreById(+show_id);

            response.data = {
                scores,
                scoresId
            };
        } catch(error){
            if(response.status === 200){
                response.status = 500;
                response.message = "SERVER_ERROR";
            }
        }finally{
            res.send(response);
        }
    }

}

export default new GameController();