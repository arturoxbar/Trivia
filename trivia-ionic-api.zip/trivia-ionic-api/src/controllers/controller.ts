import { ResponseMessage} from '../interfaces/response.interface';

export class Controller{

    constructor(name: String){
        //console.log('Controller creado: ' + name);
    }

    protected getResponse(): ResponseMessage{
        return {
            status: 200,
            message: '',
            data: null
        }
    }    

}