import { Router } from "express";
import { ensureAuth } from "../middlewares/auth.middleware";
import GameController from "../controllers/game.controller";

const gameRoutes = Router();

//CRUD
gameRoutes.all("/*", ensureAuth);
gameRoutes.get("/scores", GameController.getScores);
gameRoutes.post('/score', GameController.setScore);

export default gameRoutes;