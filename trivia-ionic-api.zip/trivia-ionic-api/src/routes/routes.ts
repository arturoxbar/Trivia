import { Router } from 'express';
import UserRoutes from './users.route';
import GameRoutes from './game.route';

const routes = Router();

// Routes
routes.use('/user', UserRoutes);
routes.use('/game', GameRoutes);

// Global routes
routes.get('/health', (req,res)=>{
    res.status(200).send('OK');
})

export default routes;