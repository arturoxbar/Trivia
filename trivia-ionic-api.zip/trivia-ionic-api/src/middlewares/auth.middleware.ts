import { NextFunction, Request, Response } from "express";
import jwt from "../services/utils/jwt";

export function ensureAuth(req: Request, res: Response, next: NextFunction) {

    if(!req.headers.authorization)
        return res.status(403).send();
    
    let token = req.headers.authorization.replace(/['"]+/g, ''),
        payload;
    
    try {
        token = token.replace('Bearer ','');
        payload = jwt.decodeToken(token);
        
        if(!payload) {
            throw new Error('Invalid token');
        }

    } catch(err) {
        return res.status(403).send({
            "message" : "El token no es válido"
        })
    }
    
    req.user = payload
    next()

}