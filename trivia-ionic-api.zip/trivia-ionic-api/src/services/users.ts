import db from "./utils/db";
import userSQL from "../templates/sql/user.json";
import { User } from "../interfaces/user.interface";

class UsersService{
    
    constructor(){
    }

    async createUser(user: any){
        let rs = await db.query(userSQL.insert, [user.name, user.email, user.password]);
        return this.parseUser({
            ...user,
            id: rs.insertId,
        });
    }

    async updateUser(user: User){
        let rs = await db.query(userSQL.update, [user.name, user.email, user.id]);
        return rs.affectedRows > 0;
    }

    async deleteUser(id: number){
        let rs = await db.query(userSQL.delete, [id]);
        return rs.affectedRows > 0;
    }

    async getUsers(){
        let rs = await db.query(userSQL.get, []);
        return rs.map((user:any)=> this.parseUser(user));
    }

    async getUserById(id: number){
        let rs = await db.query(userSQL.getById, [id]);
        return this.parseUser(rs[0]);
    }

    async getUserByEmail(email: string): Promise<User> {
        const admin = await db.query(userSQL.getByEmail, [email]);
        return this.parseUser(admin[0]);
    }

    async checkEmailExist(email: string): Promise<boolean> {
        const admin = await db.query(userSQL.getByEmail, [email]);
        console.log(email, admin)   
        return admin.length > 0;
    }

    private parseUser(user: any): User{
        return {
            id: user.id,
            name: user.name,
            email: user.email,
            status: user.status,
            password: user.password,
        }
    }

}

export default new UsersService();