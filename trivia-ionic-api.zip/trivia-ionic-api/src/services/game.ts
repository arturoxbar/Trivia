import db from "./utils/db";
import gameSQL from "../templates/sql/game.json";

class GameService {

    constructor(){        
    }

    async setScore(score: number, type_game_id: number, user_id: number){
        db.query(gameSQL.setScore, [score, type_game_id, user_id]);
    }

    async getScores(type_game_id: number){
        const scores = await db.query(gameSQL.getScores, [type_game_id]);
        return scores;
    }

    async getScore(type_game_id: number, user_id: number){
        const score = await db.query(gameSQL.getScoresByUserId, [type_game_id, user_id]);
        return score;
    }

    async getScoreById(id: number){
        const score = await db.query(gameSQL.getScoreById, [id]);
        return score[0];
    }

}

export default new GameService();