import jwt from 'jsonwebtoken';

class JWTService{

    token = `BARCODE_API`;

    constructor(){
    }

    generateToken(payload: any): string{
        return jwt.sign(payload, this.token);
    }

    verifyToken(token: string): any{
        return jwt.verify(token, this.token);
    }

    decodeToken(token: string): any{
        return jwt.decode(token);
    }

}

export default new JWTService();