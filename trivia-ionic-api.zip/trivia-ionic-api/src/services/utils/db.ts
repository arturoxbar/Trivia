import mysql from 'mysql'
import config from '../../config/db.json';

const pool = mysql.createPool(config)
const db = (() => {

  const _query = (query: string, params: any[], callback: any) => {
    pool.getConnection((err, connection) => {

      if (err) {
        console.log(err);
        connection.release()
        callback(null, err)
        throw err
      }

      connection.query(query, params, (err, rows) => {
        connection.release()
        
        if (!err)
          callback(rows)

        else
          callback(null, err)
      })

    })
  }

  const _asyncQuery = async(query: string, params: any[]) =>{
    return await new Promise((resolve,reject)=>{
      db.queryCallback(query,params,(result: any[], err: any)=>{
        if(err){
          reject(err)
        }  
        resolve(result);
    })
  }).then(data =>{return data as any })};

  return {
    query: _asyncQuery,
    queryCallback: _query
  }

})()

export default db;
